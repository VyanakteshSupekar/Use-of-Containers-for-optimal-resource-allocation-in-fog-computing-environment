
package cloudsim.ext.gui;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
public class DB_Form1 {
  public static Connection con;
    public static Statement stmt;
    public static ResultSet rs;
   public static Connection getConnection() throws ClassNotFoundException, SQLException {
        String url = "jdbc:mysql://localhost:3306/taskscheduling";
        Class.forName("com.mysql.jdbc.Driver");
        con = DriverManager.getConnection(url, "root", "");
        return con;
    }


  public static int addCount() throws ClassNotFoundException, SQLException {
        Connection con1 = getConnection();
     int count=0;
        stmt = con1.createStatement();
        String sql = "SELECT  count(uname) FROM user";
        System.out.println(sql);
        rs = stmt.executeQuery(sql);
        while (rs.next())  
             count=rs.getInt(1);
        return count ;
    }

       public static boolean VerifyLogin(String uname,String pwd) throws SQLException, ClassNotFoundException, IOException {
        boolean res = false;
        int chk = 0;
        Connection con1 = getConnection();
        stmt = con1.createStatement();
        String sql = "SELECT * FROM `registeration` WHERE `Username`='"+uname+"' and `Password`='"+pwd+"' ";
       // System.out.println(sql);
        rs = stmt.executeQuery(sql);
        while (rs.next()) {
              chk=1;
              String Res = rs.getString("FogNode");
              String FILENAMES = "D:\\Velocity_Updated_Grey_Wolf_Optimization\\ViewFog.txt";                       
                       BufferedWriter ba = null;
                       FileWriter fa = null;
                       fa = new FileWriter(FILENAMES);
                       ba = new BufferedWriter(fa);
                       ba.write(""+Res+"\n");
                       ba.close();
                       fa.close(); 
            //JOptionPane.showMessageDialog(null,"FogNode:"+ Res);
        }
        if (chk == 1) {
            res = true;
            
        } else {
            res = false;
        }
        con1.close();
        return res;
    }
}
